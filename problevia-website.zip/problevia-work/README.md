# Problevia MVP

Problem-first utility website: Search → Understand → Solve → Act.

## Included
- Problem-intent search mapping
- Percentage, age, discount, EMI, unit, date, time, GST, simple-interest, salary and electricity estimate tools
- Browser-local image compression, resize and JPG/PNG conversion
- Browser-local PDF merge, single-page split and PDF repack/compression foundation using pdf-lib
- PostgreSQL schema for problems, tools, sources, relationships, feedback and search analytics
- Calculation tests

## Run
`npm install`
`npm test`
`npm run build`
`npm run dev`

## Production gates
1. Install dependencies and pass build/tests.
2. Connect PostgreSQL and run db-schema.sql.
3. Add official sources with last-checked dates.
4. Add rate limiting, CSRF/session strategy if authenticated features are added, security headers, monitoring and backups.
5. Configure domain/DNS/HTTPS at the chosen registrar/host.
6. Deploy a production build and verify mobile accessibility, Core Web Vitals, error states and privacy pages.

## Important
No domain or trademark is claimed as cleared. “Problevia” is a working brand candidate only until registrar and trademark checks are completed.
