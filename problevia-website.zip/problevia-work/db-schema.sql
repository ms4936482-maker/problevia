CREATE TABLE IF NOT EXISTS problems(id BIGSERIAL PRIMARY KEY, slug TEXT UNIQUE NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL, language TEXT NOT NULL DEFAULT 'en', country TEXT, created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS tools(id BIGSERIAL PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active');
CREATE TABLE IF NOT EXISTS problem_tools(problem_id BIGINT REFERENCES problems(id) ON DELETE CASCADE, tool_id BIGINT REFERENCES tools(id) ON DELETE CASCADE, PRIMARY KEY(problem_id,tool_id));
CREATE TABLE IF NOT EXISTS sources(id BIGSERIAL PRIMARY KEY, title TEXT NOT NULL, url TEXT NOT NULL, authority TEXT, last_checked_at TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS problem_sources(problem_id BIGINT REFERENCES problems(id) ON DELETE CASCADE, source_id BIGINT REFERENCES sources(id) ON DELETE CASCADE, PRIMARY KEY(problem_id,source_id));
CREATE TABLE IF NOT EXISTS feedback(id BIGSERIAL PRIMARY KEY, problem_slug TEXT, tool_slug TEXT, helpful BOOLEAN, message TEXT, created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS search_events(id BIGSERIAL PRIMARY KEY, query TEXT NOT NULL, result_count INT NOT NULL DEFAULT 0, created_at TIMESTAMPTZ DEFAULT now());
CREATE INDEX IF NOT EXISTS search_events_created_idx ON search_events(created_at);
