import './globals.css';
export const metadata={title:'Problevia — Solve everyday problems',description:'Understand a problem, use the right tool, and take action.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
