import assert from 'node:assert/strict';
const pct=(n,p)=>n*p/100;const discount=(p,d)=>p*(1-d/100);const gst=(p,g)=>p*(1+g/100);const simpleInterest=(p,r,y)=>p*r*y/100;const emi=(p,annual,months)=>{const r=annual/1200;return r?p*r*(1+r)**months/((1+r)**months-1):p/months};
assert.equal(pct(200,15),30);assert.equal(discount(1000,20),800);assert.equal(gst(1000,18),1180);assert.equal(simpleInterest(10000,10,2),2000);assert.ok(Math.abs(emi(100000,12,12)-8884.88)<0.02);console.log('All calculation tests passed');
